//***************************************************************************
//
// Program example for labs in subject Operating Systems
//
// Petr Olivka, Dept. of Computer Science, petr.olivka@vsb.cz, 2017
//
// Example of socket server.
//
// This program is example of socket server and it allows to connect and serve
// the only one client.
// The mandatory argument of program is port number for listening.
//
//***************************************************************************
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <stdarg.h>
#include <poll.h>
#include <sys/socket.h>
#include <sys/param.h>
#include <sys/time.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <errno.h>
#include <sys/wait.h>
#include <sys/stat.h>

#define STR_CLOSE "close"
#define STR_QUIT "quit"
//***************************************************************************
#define LOG_ERROR 0
#define LOG_INFO 1
#define LOG_DEBUG 2

int g_debug = LOG_INFO;
void log_msg(int t_log_level, const char *t_form, ...)
{
    const char *out_fmt[] = {"ERR: (%d-%s) %s\n", "INF: %s\n", "DEB: %s\n"};
    if(t_log_level && t_log_level > g_debug) return;

    char l_buf[1024];
    va_list l_arg;
    va_start(l_arg, t_form);
    vsprintf(l_buf, t_form, l_arg);
    va_end(l_arg);

    switch(t_log_level)
    {
        case LOG_INFO:
        case LOG_DEBUG: fprintf(stdout, out_fmt[t_log_level], l_buf); break;
        case LOG_ERROR: fprintf(stderr, out_fmt[t_log_level], errno, strerror(errno), l_buf); break;
    }
}

void help(int t_narg, char **t_args)
{
    if(t_narg <= 1 || !strcmp(t_args[1], "-h"))
    {
        printf("\n""  Socket server example.\n""\n""  Use: %s [-h -d] port_number\n""\n""    -d  debug mode \n""    -h  this help\n""\n",t_args[0]);
        exit(0);
    }

    if(!strcmp(t_args[1], "-d")) g_debug = LOG_DEBUG;
}
//***************************************************************************
void sem_down() {log_msg(LOG_INFO, "Performing sem_down (simulated).");}
void sem_up() {log_msg(LOG_INFO, "Performing sem_up (simulated).");}

void handle_client(int client_sock)
{
    log_msg(LOG_INFO, "handle_client: Started client handling in process %d.", getpid());

    char cmd_buf[256];
    ssize_t cmd_len = read(client_sock, cmd_buf, sizeof(cmd_buf)-1);
    if(cmd_len <= 0)
    {
        log_msg(LOG_ERROR, "handle_client: Failed to read command from client.");
        close(client_sock);
        exit(1);
    }
    cmd_buf[cmd_len] = '\0';
    log_msg(LOG_INFO, "handle_client: Received command: '%s'", cmd_buf);
    
    const char *expected = "COMPILE ";
    if(strncmp(cmd_buf, expected, strlen(expected)) != 0)
    {
        log_msg(LOG_ERROR, "handle_client: Invalid command received.");
        close(client_sock);
        exit(1);
    }
    
    char animal[64];
    sscanf(cmd_buf + strlen(expected), "%63s", animal);
    log_msg(LOG_INFO, "handle_client: Animal to compile: '%s'", animal);
    sem_down();
    
    pid_t comp_pid = fork();
    if(comp_pid < 0)
    {
        log_msg(LOG_ERROR, "handle_client: Fork for compilation failed.");
        sem_up();
        close(client_sock);
        exit(1);
    }
    else if(comp_pid == 0)
    {
        char define_arg[80];
        snprintf(define_arg, sizeof(define_arg), "-D%s", animal);
        log_msg(LOG_INFO, "handle_client (child): Executing g++ with argument '%s'.", define_arg);

        execlp("g++", "g++", define_arg, "animal.cpp", "-o", "animal", (char *)NULL);
        log_msg(LOG_ERROR, "handle_client (child): Exec failed.");
        exit(1);
    }
    else
    {
        int status;
        wait(&status);
        int exit_code = WEXITSTATUS(status);
        log_msg(LOG_INFO, "handle_client: Compilation process exited with code %d.", exit_code);
        
        if(exit_code != 0)
        {
            const char *error_msg = "Compilation failed\n";
            write(client_sock, error_msg, strlen(error_msg));
            sem_up();
            close(client_sock);
            exit(1);
        }
    }
    
    int file_fd = open("animal", O_RDONLY);
    if(file_fd < 0)
    {
        log_msg(LOG_ERROR, "handle_client: Failed to open compiled file 'animal'.");
        sem_up();
        close(client_sock);
        exit(1);
    }
    log_msg(LOG_INFO, "handle_client: Opened compiled file 'animal'.");
    
    struct stat st;
    if(fstat(file_fd, &st) < 0)
    {
        log_msg(LOG_ERROR, "handle_client: fstat failed.");
        close(file_fd);
        sem_up();
        close(client_sock);
        exit(1);
    }
    off_t filesize = st.st_size;
    log_msg(LOG_INFO, "handle_client: File size is %ld bytes.", (long)filesize);
    
    const int buf_size = 256;
    int num_chunks = filesize / buf_size + ((filesize % buf_size) ? 1 : 0);
    int total_time_us = 5000000;
    int delay_us = (num_chunks > 0) ? total_time_us / num_chunks : total_time_us;
    log_msg(LOG_INFO, "handle_client: Will send %d chunks with a delay of %u us between chunks.", num_chunks, delay_us);
    
    char file_buf[buf_size];
    int r;
    while((r = read(file_fd, file_buf, buf_size)) > 0)
    {
        int sent = write(client_sock, file_buf, r);
        if(sent != r)
        {
            log_msg(LOG_ERROR, "handle_client: Error sending file data to client.");
            break;
        }
        log_msg(LOG_DEBUG, "handle_client: Sent %zd bytes to client.", sent);
        usleep(delay_us);
    }
    if(r < 0) log_msg(LOG_ERROR, "handle_client: Error reading from file.");
    else log_msg(LOG_INFO, "handle_client: Finished sending file to client.");
    
    sem_up();
    close(file_fd);
    close(client_sock);
    log_msg(LOG_INFO, "handle_client: Closed file and client socket. Exiting process.");
    exit(0);
}

int main(int t_narg, char **t_args)
{
    if(t_narg <= 1) help(t_narg, t_args);
    int l_port = 0;

    for(int i = 1; i < t_narg; i++)
    {
        if(!strcmp(t_args[i], "-d")) g_debug = LOG_DEBUG;
        if(!strcmp(t_args[i], "-h")) help(t_narg, t_args);
        if(*t_args[i] != '-' && !l_port)
        {
            l_port = atoi(t_args[i]);
            break;
        }
    }

    if(l_port <= 0)
    {
        log_msg(LOG_INFO, "Bad or missing port number %d!", l_port);
        help(t_narg, t_args);
    }

    log_msg(LOG_INFO, "Server will listen on port: %d.", l_port);

    int l_sock_listen = socket(AF_INET, SOCK_STREAM, 0);
    if(l_sock_listen == -1)
    {
        log_msg(LOG_ERROR, "Unable to create socket.");
        exit(1);
    }

    in_addr l_addr_any = {INADDR_ANY};
    sockaddr_in l_srv_addr;
    l_srv_addr.sin_family = AF_INET;
    l_srv_addr.sin_port = htons(l_port);
    l_srv_addr.sin_addr = l_addr_any;

    int l_opt = 1;
    if(setsockopt(l_sock_listen, SOL_SOCKET, SO_REUSEADDR, &l_opt, sizeof(l_opt)) < 0) log_msg(LOG_ERROR, "Unable to set socket option!");
    if(bind(l_sock_listen, (const sockaddr *)&l_srv_addr, sizeof(l_srv_addr)) < 0)
    {
        log_msg(LOG_ERROR, "Bind failed!");
        close(l_sock_listen);
        exit(1);
    }
    if(listen(l_sock_listen, 1) < 0)
    {
        log_msg(LOG_ERROR, "Unable to listen on given port!");
        close(l_sock_listen);
        exit(1);
    }
    log_msg(LOG_INFO, "Enter 'quit' to quit server.");

    int l_sock_client = -1;
    while(1)
    {
        int l_sock_client = -1;
        pollfd l_read_poll[2];
        l_read_poll[0].fd = STDIN_FILENO;
        l_read_poll[0].events = POLLIN;
        l_read_poll[1].fd = l_sock_listen;
        l_read_poll[1].events = POLLIN;

        while(1)
        {
            int l_poll = poll(l_read_poll, 2, -1);
            if(l_poll < 0)
            {
                log_msg(LOG_ERROR, "Function poll failed!");
                exit(1);
            }

            if(l_read_poll[0].revents & POLLIN)
            {
                char buf[128];
                int len = read(STDIN_FILENO, buf, sizeof(buf));
                if(len < 0)
                {
                    log_msg(LOG_DEBUG, "Unable to read from stdin!");
                    exit(1);
                }

                log_msg(LOG_DEBUG, "Read %d bytes from stdin");
                if(!strncmp(buf, STR_QUIT, strlen(STR_QUIT)))
                {
                    log_msg(LOG_INFO, "Request to 'quit' entered.");
                    close(l_sock_listen);
                    exit(0);
                }
            }

            if(l_read_poll[1].revents & POLLIN)
            {
                sockaddr_in l_rsa;
                int l_rsa_size = sizeof(l_rsa);
                l_sock_client = accept(l_sock_listen, (sockaddr *)&l_rsa, (socklen_t *)&l_rsa_size);
                if(l_sock_client == -1)
                {
                    log_msg(LOG_ERROR, "Unable to accept new client.");
                    close(l_sock_listen);
                    exit(1);
                }
                uint l_lsa = sizeof(l_srv_addr);
                getsockname(l_sock_client, (sockaddr *)&l_srv_addr, &l_lsa);
                log_msg(LOG_INFO, "My IP: '%s'  port: %d",inet_ntoa(l_srv_addr.sin_addr), ntohs(l_srv_addr.sin_port));

                getpeername(l_sock_client, (sockaddr *)&l_srv_addr, &l_lsa);
                log_msg(LOG_INFO, "Client IP: '%s'  port: %d",inet_ntoa(l_srv_addr.sin_addr), ntohs(l_srv_addr.sin_port));
                break;
            }
        }
    }

    pid_t pid = fork();
    if(pid < 0)
    {
        log_msg(LOG_ERROR, "Fork failed for new client.");
        close(l_sock_client);
    }
    else if(pid == 0)
    {
        handle_client(l_sock_client);
        exit(0);
    }
    else
    {
        close(l_sock_client);
        log_msg(LOG_INFO, "Spawned child process %d for client. Waiting for new client...", pid);
    }
    return 0;
}