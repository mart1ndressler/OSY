#include <iostream>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <string.h>
#include <sys/types.h>
#include <pthread.h>
#include <semaphore.h>
#include <fcntl.h>
#include <vector>

using namespace std;

#define LIMIT 100
#define PORT 8080

struct Pokladnicka 
{
    int suma;
    char mince[1024];
};

Pokladnicka pokladnicka = {0, ""};
sem_t semaphore;
int security_socket = -1;

void *handle_client(void *arg) 
{
    int client_socket = *(int *)arg;
    cout << "[SERVER] Client connected." << endl;

    while(1) 
    {
        char buffer[1024] = {0};
        int bytes_read = read(client_socket, buffer, sizeof(buffer));
        if(bytes_read <= 0) 
        {
            cout << "[SERVER] Client disconnected." << endl;
            break;
        }

        if(strcmp(buffer, "END") == 0) break;

        char *token = strtok(buffer, " ");
        while(token != NULL) 
        {
            int coin = atoi(token);
            if(coin != 1 && coin != 2 && coin != 5 && coin != 10 && coin != 20 && coin != 50) 
            {
                string invalid_msg = "Invalid coin value! Please send 1, 2, 5, 10, 20, or 50!\n";
                send(client_socket, invalid_msg.c_str(), invalid_msg.size(), 0);
                token = strtok(NULL, " ");
                continue;
            }

            sem_wait(&semaphore);
            pokladnicka.suma += coin;
            strcat(pokladnicka.mince, token);
            strcat(pokladnicka.mince, " ");
            sem_post(&semaphore);

            cout << "[SERVER] Received from client: " << coin << " (current sum: " << pokladnicka.suma << ")" << endl;

            if(pokladnicka.suma >= LIMIT) 
            {
                cout << "[SERVER] Cashbox exceeds limit, sending to security!" << endl;
                if(security_socket != -1) 
                {
                    string message = "Transporting cashbox: " + string(pokladnicka.mince) + "(sum: " + to_string(pokladnicka.suma) + ")\n";
                    send(security_socket, message.c_str(), message.size(), 0);
                }
                pokladnicka.suma = 0;
                memset(pokladnicka.mince, 0, sizeof(pokladnicka.mince));
            }

            token = strtok(NULL, " ");
        }
        sem_wait(&semaphore);
        string feedback = "Current cashbox sum: " + to_string(pokladnicka.suma) + "\n";
        sem_post(&semaphore);
        send(client_socket, feedback.c_str(), feedback.size(), 0);
    }

    close(client_socket);
    return NULL;
}

int main() 
{
    sem_init(&semaphore, 0, 1);

    int server_socket = socket(AF_INET, SOCK_STREAM, 0), opt = 1, addrlen = sizeof(sockaddr_in);
    if(server_socket == 0) 
    {
        perror("[SERVER] Socket failed");
        exit(EXIT_FAILURE);
    }

    sockaddr_in address;
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = INADDR_ANY;
    address.sin_port = htons(PORT);

    setsockopt(server_socket, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT, &opt, sizeof(opt));
    bind(server_socket, (struct sockaddr *)&address, sizeof(address));
    listen(server_socket, 3);

    cout << "[SERVER] Server running on port " << PORT <<"..." << endl;

    pthread_t security_thread;
    security_socket = accept(server_socket, (struct sockaddr *)&address, (socklen_t *)&addrlen);
    cout << "[SERVER] Security client connected." << endl;

    while(1) 
    {
        int client_socket = accept(server_socket, (struct sockaddr *)&address, (socklen_t *)&addrlen);
        pthread_t client_thread;
        pthread_create(&client_thread, nullptr, handle_client, &client_socket);
    }

    sem_destroy(&semaphore);
    close(server_socket);
    return 0;
}