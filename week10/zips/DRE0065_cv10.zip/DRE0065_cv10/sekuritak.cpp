#include <iostream>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <string.h>
#include <arpa/inet.h>

using namespace std;

#define PORT 8080

int main() {
    int client_socket = socket(AF_INET, SOCK_STREAM, 0);
    if(client_socket == 0) 
    {
        perror("[SECURITY] Socket failed");
        return -1;
    }

    sockaddr_in serv_addr;
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(PORT);

    inet_pton(AF_INET, "127.0.0.1", &serv_addr.sin_addr);
    connect(client_socket, (struct sockaddr *)&serv_addr, sizeof(serv_addr));
    cout << "[SECURITY] Connected to the server, waiting for cashbox updates..." << endl;

    while(1) 
    {
        char buffer[1024] = {0};
        int bytes_read = read(client_socket, buffer, sizeof(buffer));
        if(bytes_read > 0) cout << "[SECURITY] " << buffer;
    }

    close(client_socket);
    return 0;
}